#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <threads.h>
#include <complex.h>


const float UPPER_BOUND = 1e10;
const float LOWER_BOUND = 1e-3;
const int MAX_Iter = 128;
const int DEFAULT_VALUE = 9;

static inline void newton1(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x-1 = 0
    float r1_re = 1;
    float r1_im = 0;
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 1; ++ix){//degree 1: number of roots = 1
            diff_re = creal(x) - r1_re;
            diff_im = cimag(x) - r1_im;
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("degree 1 diff: %f\n", (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;
        x = 1;
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton2(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^2-1 = 0
    float r1_re[2] = {1, -1};
    float r1_im[2] = {0, 0};
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 2; ++ix){//degree 2: number of roots = 2
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;

        float norm = creal(x)*creal(x) + cimag(x)* cimag(x);
        x -= 0.5 * (x - creal(x)/norm + (cimag(x)/norm)*I);
        
        //x = 0.5f * x + 0.5f / x;
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton3(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^3-1 = 0
    float r1_re[3] = {1, -0.5, -0.5};
    float r1_im[3] = {0, 0.86603, -0.86603};

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 3; ++ix){//degree 2: number of roots = 2
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;

        //float norm = creal(x)*creal(x) + cimag(x)* cimag(x);
        //x -= 0.5 * (x - creal(x)/norm + (cimag(x)/norm)*I);
        
        x = 0.6666666666f * x + 0.3333333333f / (x * x);
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton4(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^4-1 = 0
    float r1_re[4] = {1, 0, -1, 0};
    float r1_im[4] = {0, 1, 0, -1};
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 4; ++ix){//degree 4: number of roots = 4
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;

        x = 0.75f * x + 0.25f / (x * x * x);
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton5(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^5-1 = 0
    float r1_re[5] = {1, 0.309017, -0.809017, -0.809017, 0.309017};
    float r1_im[5] = {0, 0.951057, 0.587785, -0.587785, -0.951057};
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 5; ++ix){//degree 5: number of roots = 5
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;
        
        x = 0.8f * x + 0.2f / (x * x * x * x);
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton6(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^6-1 = 0
    float r1_re[6] = {1, 0.5, -0.5, -1, -0.5, 0.5};
    float r1_im[6] = {0, 0.866025, 0.866025, 0, -0.866025, -0.866025};
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 6; ++ix){//degree 6: number of roots = 6
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;

        x = 0.8333333333f * x + 0.1666666666f / (x * x * x * x * x);
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton7(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^7-1 = 0
    float r1_re[7] = {1, 0.62349, -0.222521, -0.900969, -0.900969, -0.222521, 0.62349};
    float r1_im[7] = {0, 0.781831, 0.974928, 0.433884, -0.433884, -0.974928, -0.781831};
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 7; ++ix){//degree 7: number of roots = 7
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;

        x = 0.85714286f * x + 0.14285714f / (x * x * x * x * x * x);
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton8(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^8-1 = 0
    float r1_re[8] = {1, 0.707107, 0, -0.707107, -1, -0.707107, 0, 0.707107};
    float r1_im[8] = {0, 0.707107, 1, 0.707107, 0, -0.707107, -1, -0.707107};
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 8; ++ix){//degree 8: number of roots = 8
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;

        x = 0.875f * x + 0.125f / (x * x * x * x * x * x * x);
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}

static inline void newton9(float complex x, int* attr, int* conv){
    // Set the default value of attr and conv first
    *attr = DEFAULT_VALUE;
    *conv = -1;

    // root of x^9-1 = 0
    float r1_re[9] = {1, 0.766044, 0.173648, -0.5, -0.939693, -0.939693, -0.5, 0.173648, 0.766044};
    float r1_im[9] = {0, 0.642788, 0.984808, 0.866025, 0.34202, -0.34202, -0.866025, -0.984808, -0.642788};
    //int num_root = 1;

    //store the value of the difference
    float diff_re, diff_im;

    int iter, a;
    // Start the iteration
    for (iter = 0; iter < MAX_Iter; ++iter){
        // Set a to the default value first
        a = DEFAULT_VALUE;
        // check the condition 
        if ( fabsf(creal(x)) > UPPER_BOUND || (creal(x)*creal(x) + cimag(x)* cimag(x)) < (LOWER_BOUND*LOWER_BOUND) 
        || fabsf(cimag(x)) > UPPER_BOUND){
            *attr = DEFAULT_VALUE;
            break;
        }

        for (int ix = 0; ix < 9; ++ix){//degree 9: number of roots = 9
            diff_re = creal(x) - r1_re[ix];
            diff_im = cimag(x) - r1_im[ix];
            if ((diff_re*diff_re + diff_im * diff_im) < (LOWER_BOUND*LOWER_BOUND)){
                //printf("root %i, degree 2 diff: %f\n", ix, (diff_re*diff_re + diff_im * diff_im));
                a = ix;
                *attr = ix;
                break;
            }
        }

        if ( a != DEFAULT_VALUE )
            break;

        x = 0.8888888888f * x + 0.1111111111f / (x * x * x * x * x * x * x * x);
        
        //printf("iter %i, updated x %f, real %f, img %f\n", iter, x, creal(x), cimag(x));
    }
    *conv = iter < MAX_Iter ? iter : MAX_Iter;
}
