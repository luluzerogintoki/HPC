#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <threads.h>
#include <complex.h>
#include "newton.h"

/*
Trial 1: check data transfer between compute thrd and write thrd
- no computation
- only use the initialization value to draw the figure

Trial 2:

*/

int nthrds, size, exponent;

typedef struct{
    //size_t num_thrd; //number of threads
    int** attr; //store the value of attractor
    int** conv; //store the value of convergence
    int thrd_no;
    int ib;
    int size;
    int step;
    int exponent;
    int* status; //track the line being calculated, if = 1 yes, else no
    mtx_t *mtx;
    cnd_t *cnd;//conditional variable used to check 
}thrd_compute;

typedef struct{
    int** attr;
    int** conv;
    int size;
    int nthrd;
    int* status;
    mtx_t *mtx;
    cnd_t *cnd;
    FILE *attr_file;
    FILE *conv_file;
}thrd_write;

char *colormap[10] = {
    "148 000 211 ", "075 000 130 ", "000 000 255 ", "000 255 000 ", "255 255 000 ",
    "255 127 000 ", "255 000 000 ", "102 194 165 ", "050 136 189 ", "094 079 162 "
};


char *colormap_gray[129] = {
    "002 002 002 ", "004 004 004 ", "006 006 006 ", "008 008 008 ", "010 010 010 ",
    "005 005 005 ", "007 007 007 ", "009 009 009 ", "011 011 011 ", "013 013 013 ",
    "017 017 017 ", "019 019 019 ", "021 021 021 ", "023 023 023 ", "025 025 025 ",
    "029 029 029 ", "031 031 031 ", "033 033 033 ", "035 035 035 ", "037 037 037 ",
    "041 041 041 ", "043 043 043 ", "045 045 045 ", "047 047 047 ", "049 049 049 ",
    "053 053 053 ", "055 055 055 ", "057 057 057 ", "059 059 059 ", "061 061 061 ",
    "065 065 065 ", "067 067 067 ", "069 069 069 ", "071 071 071 ", "073 073 073 ",
    "077 077 077 ", "079 079 079 ", "081 081 081 ", "083 083 083 ", "085 085 085 ",
    "089 089 089 ", "091 091 091 ", "093 093 093 ", "095 095 095 ", "097 097 097 ",
    "101 101 101 ", "103 103 103 ", "105 105 105 ", "107 107 107 ", "109 109 109 ",
    "113 113 113 ", "115 115 115 ", "117 117 117 ", "119 119 119 ", "121 121 121 ",
    "125 125 125 ", "127 127 127 ", "129 129 129 ", "131 131 131 ", "133 133 133 ",
    "137 137 137 ", "139 139 139 ", "141 141 141 ", "143 143 143 ", "145 145 145 ",
    "149 149 149 ", "151 151 151 ", "153 153 153 ", "155 155 155 ", "157 157 157 ",
    "161 161 161 ", "163 163 163 ", "165 165 165 ", "167 167 167 ", "169 169 169 ",
    "173 173 173 ", "175 175 175 ", "177 177 177 ", "179 179 179 ", "181 181 181 ",
    "185 185 185 ", "187 187 187 ", "189 189 189 ", "191 191 191 ", "193 193 193 ",
    "197 197 197 ", "199 199 199 ", "201 201 201 ", "203 203 203 ", "205 205 205 ",
    "209 209 209 ", "211 211 211 ", "213 213 213 ", "215 215 215 ", "217 217 217 ",
    "221 221 221 ", "223 223 223 ", "225 225 225 ", "227 227 227 ", "229 229 229 ",
    "233 233 233 ", "235 235 235 ", "237 237 237 ", "239 239 239 ", "241 241 241 ",
    "245 245 245 ", "247 247 247 ", "249 249 249 ", "251 251 251 ", "253 253 253 ",
    "198 198 198 ", "200 200 200 ", "202 202 202 ", "204 204 204 ", "206 206 206 ",
    "208 208 208 ", "210 210 210 ", "212 212 212 ", "214 214 214 ", "216 216 216 ",
    "218 218 218 ", "220 220 220 ", "222 222 222 ", "224 224 224 ", "226 226 226 ",
    "228 228 228 ", "230 230 230 ", "232 232 232 ", "234 234 234 ",
};




static inline int compute_thread(void *args)
{
    thrd_compute *c = (thrd_compute*) args;
    int** attr = c->attr;
    int** conv = c->conv;
    int ib = c->ib;
    int size = c->size;
    int step = c->step;
    int exponent = c->exponent;
    int thrd_no = c->thrd_no;
    int* status = c->status;
    mtx_t *mtx = c->mtx;
    cnd_t *cnd = c->cnd;

    // Convert the coordinates into [-2;2] scale
    float real_coor[size],img_coor[size];
    for (size_t ix = 0; ix < size; ++ix){
        float temp = size - 1;
        real_coor[ix] = -2 + (4./ temp) * (ix);
        img_coor[ix] = 2 - (4./ temp) *(ix);
    }

    for (size_t ix = ib; ix < size; ix += step){
        int* attr_row = (int*) malloc(sizeof(int)*size);
        int* conv_row = (int*) malloc(sizeof(int)*size);
       //double limit = -(ix*(4.0/size) - 2.0); // [-2, 2]
        float temp = size - 1;
        int* attr_ptr = attr_row;
        int* conv_ptr = conv_row;
/*        
for (int j = 0; j < rowSize; j++){
	double complex z = (j*(4.0/rowSize) - 2.0) + limit*I;
	newtonIteration(z, attractor+j, convergence+j, degree);
}*/
        for (size_t jx = 0; jx < size; ++jx){
            //printf("Thread:%i\n", ib);
            //printf("row+col:%i+%i ", ix, jx);
            attr_row[jx] = 9;
            conv_row[jx] = -1;
            //double complex z = (jx*(4.0/size) - 2.0) + limit*I;

            double complex z = (-2 + (4./ temp) * (jx)) + (2 - (4./ temp) *(ix)) * I;
            //printf("complex number get: %f\n", z);
            //printf("real part: %f img part: %f\n", (-2 + (4./ temp) * (jx)), (2 - (4./ temp) *(ix)));
            switch(exponent){
                case 1:
                    newton1(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                case 2:
                    newton2(z, attr_ptr+jx, conv_ptr+jx);;
                    break;
                case 3:
                    newton3(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                case 4:
                    newton4(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                case 5:
                    newton5(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                case 6:
                    newton6(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                case 7:
                    newton7(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                case 8:
                    newton8(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                case 9:
                    newton9(z, attr_ptr+jx, conv_ptr+jx);
                    break;
                default:
                    printf("Invalid input for exponent.\n");
                    exit(1);
            }
        }
        //printf("attr:%i\n", attr_row[jx]);
        //printf("conv:%i\n", conv_row[jx]);
        mtx_lock(c->mtx);
        attr[ix] = attr_row;
        conv[ix] = conv_row;
        if ((ix + step) >= size){
            status[thrd_no] = 1000000;
        }
        else
            status[thrd_no] = ix;
        mtx_unlock(c->mtx);
        cnd_signal(cnd);
    }

    return 0;
}

static inline int write_block(void *args){
    thrd_write *write = (thrd_write*) args;
    int **attr = write->attr;
    int **conv = write->conv;
    int* status = write->status;
    FILE *attr_file = write->attr_file;
    FILE *conv_file = write->conv_file;
    int size = write->size;
    int nthrd = write->nthrd;
    mtx_t *mtx = write->mtx;
    cnd_t *cnd = write->cnd;

    char attractor_str[size * 12];
    char convergence_str[size * 12];
	// buffer
	//setvbuf(attr_file, attractorPixel, _IOFBF, size*12);
	//setvbuf(conv_file, convergencePixel, _IOFBF, size*12);

    int bound = size;
    for (int ix = 0; ix < size; ){
        mtx_lock(mtx);
        {
            bound = size;
            int complete = 0;
            for (int j=0; j<nthrd; ++j){
                int check = status[j];
                if (check < bound)
                    bound = check;
                if (check == 1000000)
                    complete++;
            }

            if(complete == nthrds){
                bound = size - 1;
                mtx_unlock(mtx);
            }
            else if (bound <= ix){
                cnd_wait(cnd, mtx);
                mtx_unlock(mtx);
                continue;
            }
            else{
                mtx_unlock(mtx);
            }

            for(; ix<bound+1; ix++){

                int *attr_row = attr[ix];
                int *conv_row = conv[ix];

                int index = 0;
                for (int j = 0; j<size; ++j){
                    //printf("attr: %d %d : %d \n", ix, j, attr_row[j]);
                    //printf("conv: %d %d : %d \n", ix, j, conv_row[j]);
                    if (attr_row[j] < 0 || attr_row[j] > 9){
                        printf("attr: %d %d : %d \n", ix, j, attr_row[j]);
                    }
                    if (conv_row[j] < 0 || conv_row[j] > 128){
                        printf("conv: %d %d : %d \n", ix, j, conv_row[j]);
                        printf("attr: %d %d : %d \n", ix, j, attr_row[j]);
                        printf("colormap %s", colormap_gray[conv_row[j]]);
                    }
                    memcpy(attractor_str + 12 * j, colormap[attr_row[j]], 12*sizeof(char));
                    memcpy(convergence_str + 12 * j, colormap_gray[conv_row[j]], 12*sizeof(char));
                }

                attractor_str[12 * size - 1] = '\n';
                convergence_str[12 * size - 1] = '\n';

                //free(attr_row);
                //free(conv_row);

                fwrite(attractor_str, sizeof(char), 12 * size, attr_file);
                fwrite(convergence_str, sizeof(char), 12 * size, conv_file);
                
                free(attr_row);
                free(conv_row);
            }

            
        }
    }

    return 0;
}


int main(int argc, char *argv[]){
    // Part I: Parsing command line arguments
    
    /*Your program should accept command line arguments
    ./newton -t5 -l1000 7
    ./newton -l1000 -t5 7*/
    if (argc != 4){
        printf("Invalid input!");
        return -1;
    }
    
    char *t, *l;
    for (int ix = 1; ix < argc; ++ix){
        t = strchr(argv[ix], 't');
        l = strchr(argv[ix], 'l');
        if (t){
            nthrds = strtol(++t, NULL, 10);
        }
        else if (l){
            size = strtol(++l, NULL, 10);
        }
        else{
            exponent = strtol(argv[ix], NULL, 10);
        }
    }
    
    //printf("nthrds:%i\n", nthrds);
    //printf("size:%i\n", size);
    //printf("exponent:%i\n", exponent);


    // Part II: Synchronization of compute and write threads
    // Initialize attractor, convergence arrays
    int** attractor = (int**) malloc(sizeof(int*) * size);
    int** convergence = (int**) malloc(sizeof(int*) * size);


    thrd_t thrds[nthrds];
    thrd_compute thrds_compute[nthrds];
    int r; //for thrd_join and thrd_create
    int thrd_status[nthrds]; //store the status of each thread

    mtx_t mtx;
    mtx_init(&mtx, mtx_plain);

    cnd_t cnd;
    cnd_init(&cnd);

    for (int tx = 0; tx < nthrds; ++tx){
        thrds_compute[tx].attr = attractor;
        thrds_compute[tx].conv = convergence;
        thrds_compute[tx].status = thrd_status;
        thrds_compute[tx].thrd_no = tx;
        thrds_compute[tx].ib = tx;
        thrds_compute[tx].size = size;
        thrds_compute[tx].step = nthrds;
        thrds_compute[tx].exponent = exponent;
        thrds_compute[tx].mtx = &mtx;
        thrds_compute[tx].cnd = &cnd;
        //Part IV: Checking the convergence and divergence conditions.
        // Part V: Computation of of x_n in the iteration step.
        r = thrd_create(thrds+tx, compute_thread, (void*)(thrds_compute+tx));
        if (r){
            printf("Failed to create thread\n");
            exit(1);
        }
    }


    // Part VI: Writing to file.
    // Create the header of PPM files
    FILE *attr_file;
    char fname1[25];
    sprintf(fname1, "newton_attractors_x%d.ppm", exponent);
    attr_file = fopen(fname1, "w");
    fprintf(attr_file, "P3\n");
    fprintf(attr_file, "%d %d\n", size, size); // number of rows and columns 
    fprintf(attr_file, "255\n"); //maximal color value 

    FILE *conv_file;
    char fname2[25];
    sprintf(fname2, "newton_convergence_x%d.ppm", exponent);
    conv_file = fopen(fname2, "w");
    fprintf(conv_file, "P3\n");
    fprintf(conv_file, "%d %d\n", size, size);
    fprintf(conv_file, "255\n");

    // Part III: Data transfer between compute and write threads.
    thrd_t write_thrd;
    thrd_write write;
    
    write.attr = attractor;
    write.conv = convergence;
    write.status = thrd_status;
    write.size = size;
    write.nthrd = nthrds;
    write.mtx = &mtx;
    write.cnd = &cnd;
    write.attr_file = attr_file;
    write.conv_file = conv_file;
    thrd_create(&write_thrd, write_block, (void*)(&write));


    // Destroy threads, mutex,..
    for (int tx=0; tx < nthrds; ++tx) {
        int result = thrd_join(thrds[tx], NULL);
        //printf("thread%i, return%i:\n",tx, result);
        if (result != thrd_success){
            printf("Failed to join thread: %i\n", tx);
            exit(1);
        }
    }
    thrd_join(write_thrd, NULL);

    
    // Close the files
    fclose(attr_file);
    fclose(conv_file);

    // Free the allocated memory
    free(attractor);
    free(convergence);

    cnd_destroy(&cnd);
    mtx_destroy(&mtx);


    return 0;
}